package Exceptions;

public class KweetException extends Exception {

    public KweetException(String msg) {
        super(msg);
    }
}
