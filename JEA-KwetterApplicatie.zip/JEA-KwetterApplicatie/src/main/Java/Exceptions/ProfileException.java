package Exceptions;

public class ProfileException extends Exception {

    public ProfileException(String msg) {
        super(msg);
    }
}
